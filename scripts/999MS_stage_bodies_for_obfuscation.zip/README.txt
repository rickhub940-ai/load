999MS stage bodies for obfuscation
==================================

Contains the code between BODY BEGIN and BODY END from the current source files:
- loada_body.lua  <- lib/loada.lua
- loadc_body.lua  <- lib/loadc.lua
- loader_body.lua <- lib/loader.lua
- payload_body.lua <- lib/payload.lua (includes the clipboard fix)

Obfuscate each body separately. Keep each stage wrapper/header outside the obfuscator;
the stage files use that wrapper for positional arguments, chain tokens, and hashing.
